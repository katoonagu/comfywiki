import os

AUX = "/mnt/raid0/ComfyUI/models/vae"
TARGET = "/home/comfyui/ComfyUI/models/vae"

def sync_aux_models():
    os.makedirs(TARGET, exist_ok=True)

    aux_models = [
        os.path.join(AUX, f) for f in os.listdir(AUX)
        if os.path.isfile(os.path.join(AUX, f))
    ]

    existing_symlinks = [
        os.path.join(TARGET, f) for f in os.listdir(TARGET)
        if os.path.islink(os.path.join(TARGET, f))
    ]

    # Remove broken symlinks
    for link in existing_symlinks:
        if not os.path.exists(os.readlink(link)):
            print(f"Removing broken symlink: {link}")
            os.unlink(link)

    # Create correct symlinks
    for model in aux_models:
        target_link = os.path.join(TARGET, os.path.basename(model))
        if not os.path.exists(target_link):
            os.symlink(model, target_link)
            print(f"Created symlink: {target_link} → {model}")
