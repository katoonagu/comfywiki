from .sync_aux_models import sync_aux_models
sync_aux_models()
